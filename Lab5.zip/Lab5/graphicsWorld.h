/*
 *  graphicsWorld.h
 *  ENSF 614 Lab 5, Exercise A
 *  Class Header file for Square.
 *  Completed by: Hassaan Ahmed Zuberi
 *  Submitted on: Oct 22, 2022
 */

#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld
{
public:
    void run();
};

#endif
